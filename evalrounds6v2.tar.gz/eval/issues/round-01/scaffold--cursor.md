<!-- base-branch: eval/cursor -->
<!-- eval-round: 1 -->
<!-- eval-spec: scaffold -->
<!-- eval-agent: cursor -->

## Why

Nothing else can be built until the app skeleton, database client and CI entry points exist.

## Scope

Create a Next.js 14 (App Router) + TypeScript + Tailwind + Prisma + Postgres application in this repository.

## Non-Goals

Do not modify any file under `.github/` — those workflows are centrally managed.

## Tasks

- [ ] Initialize the app with `package.json`, `next.config.js` and `tsconfig.json`
- [ ] Add `app/globals.css`: add Tailwind via `tailwind.config.ts` and
- [ ] Add `prisma/schema.prisma`: add Prisma with a Postgres datasource
- [ ] Add `/api/health`: create the  route in `app/api/health/route.ts` returning `{ok, version}`
- [ ] Add `.env.example` declaring `DATABASE_URL` and `NEXTAUTH_SECRET`
- [ ] Configure `.eslintrc.json`, `.prettierrc` and `.editorconfig`
- [ ] Add `dev`, `build` and `test` scripts to `package.json`

## Acceptance Criteria

- [ ] `GET /api/health` returns HTTP 200 with a JSON body
- [ ] `pnpm test` passes
- [ ] `pnpm build` completes and `pnpm dev` starts the server
- [ ] CI is green on this pull request

## Implementation Notes

Seeded for the `cursor` evaluation lane. Work on the branch cut for this issue and open the pull request against `eval/cursor`. Keep changes limited to the files named in Tasks.

<details>
<summary>Original Issue</summary>

```text
Seeded from eval/rounds/round-01.json, spec `scaffold`, agent `cursor`.
```

</details>
