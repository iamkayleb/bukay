<!-- base-branch: eval/codex -->
<!-- eval-round: 9 -->
<!-- eval-spec: deposits -->
<!-- eval-agent: codex -->

## Why

Deposits are the merchant's main defence against no-shows and a core selling point.

## Scope

Per-service deposit as percentage or flat amount, with balance capture and no-show fees.

## Non-Goals

Nothing beyond the scope above. Do not modify files under `.github/`.

## Tasks

- [ ] Add `prisma/schema.prisma`: add deposit columns to the `Service` model
- [ ] Add `app/lib/payments/split.ts`: split deposit and balance records
- [ ] Add `app/api/payments/capture/route.ts`: implement
- [ ] Add `app/lib/payments/no-show.ts`: implement the no-show fee path

## Acceptance Criteria

- [ ] A deposit-only booking holds status `confirmed_partial`, verified by `pnpm test`
- [ ] Balance capture returns HTTP 200 and closes the booking
- [ ] The no-show fee writes a `LedgerEntry` row
- [ ] `pnpm test` passes

## Implementation Notes

Seeded for the `codex` evaluation lane. Work on the branch cut for this issue and open the pull request against `eval/codex`. Keep changes limited to the files named in Tasks. This repository puts application code under `app/` (for example `app/lib/`) and tests under `__tests__/`; follow the existing layout rather than creating a parallel tree.

<details>
<summary>Original Issue</summary>

```text
Seeded from eval/rounds/round-09.json, spec `deposits`, agent `codex`.
```

</details>
